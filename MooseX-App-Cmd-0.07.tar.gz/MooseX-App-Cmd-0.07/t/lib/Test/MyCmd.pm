package Test::MyCmd;
use Moose;

extends qw(MooseX::App::Cmd);

1;
