package Test::MyCmd::Command::stock;
use Moose;

extends qw(MooseX::App::Cmd::Command);

=head1 NAME

Test::MyCmd::Command::stock - nothing here is overridden

=cut

# This package exists to test all the default command plugin behaviors.

1;
